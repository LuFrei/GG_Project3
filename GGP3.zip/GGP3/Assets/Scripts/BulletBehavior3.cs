﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior3 : MonoBehaviour {

    public float bulletSpeed;
	
	
	void Update () {
        transform.Translate(Vector2.up * bulletSpeed * Time.deltaTime);
	}

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Wall"))     
        {
            Destroy(gameObject);
        }                                            

        if (other.gameObject.tag != "Player 3" && other.gameObject.tag != "Wall")
        {
            other.gameObject.transform.localScale -= new Vector3(0.5f, 0.5f, 0f);
            Destroy(gameObject);
        }
    }
}
