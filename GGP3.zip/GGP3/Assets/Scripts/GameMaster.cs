﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMaster : MonoBehaviour {

	public float startingSize;
    public GameObject[] players;
    public PlayerController PControl;

    public int deathCount;

    public int playerCount;



    private void Start()
    {
        players[0] = GameObject.Find("P1");
        players[1] = GameObject.Find("P2");
        players[2] = GameObject.Find("P3");
        players[3] = GameObject.Find("P4");

        PControl = GetComponent<PlayerController>();

                    //player count, default to 4 until menu stuff works

        if (playerCount == 2)
        {
            //Instantiate(player, GameObject.Find("Spawner 1").transform.position, GameObject.Find("Spawner 1").transform.rotation);
        }
    }
    // Update is called once per frame
    void Update() {
        for (int i=0; i < players.Length; i++)
        {
            

            //Declares winner
            if(deathCount == 3)
            {
                if(players[i].GetComponent<PlayerController>().isDead == false)
                {
                    Debug.Log(players[i] + "won the game!");
                }
            }
            
        }

        
	}

    
}
