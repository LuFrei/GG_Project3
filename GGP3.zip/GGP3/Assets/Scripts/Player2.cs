﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XInputDotNetPure;

public class Player2 : MonoBehaviour
{

    bool playerIndexSet = false;
    public PlayerIndex playerIndex = PlayerIndex.Two;
    public GamePadState state;
    public GamePadState prevState;
    public float speed = 8.0f;
    public GameMaster gm;
    public bool isDead = false;

    public Rigidbody2D rgb2D;
    public Transform bulletPoint;
    public GameObject bullet;
    public string whatever;
    void Start()
    {
        playerIndex = PlayerIndex.Two;

        gm = GameObject.Find("GameMaster").GetComponent<GameMaster>();
        rgb2D = GetComponent<Rigidbody2D>();
        Debug.Log("Start");
        bulletPoint = GameObject.Find(whatever).GetComponentInChildren<Transform>();

        gameObject.transform.localScale = new Vector3(gm.startingSize, gm.startingSize, 0);
    }

    void FixedUpdate()
    {
        playerIndex = PlayerIndex.Two;

    }

    void Update()
    {
        if (!playerIndexSet || !prevState.IsConnected)
        {
            for (int i = 0; i < 4; ++i)
            {
                PlayerIndex testPlayerIndex = (PlayerIndex)i;
                GamePadState testState = GamePad.GetState(testPlayerIndex);
                if (testState.IsConnected)
                {
                    Debug.Log(string.Format("GamePad found {0}", testPlayerIndex));
                    playerIndex = testPlayerIndex;
                    playerIndexSet = true;
                }
            }
        }

        prevState = state;
        state = GamePad.GetState(playerIndex);

        if (playerIndex == PlayerIndex.Two && prevState.Buttons.A == ButtonState.Released && state.Buttons.A == ButtonState.Pressed)
        {
            Instantiate(bullet, bulletPoint.position, bulletPoint.rotation);
        }

        if (playerIndex == PlayerIndex.Two)
        {
            transform.localPosition += new Vector3(state.ThumbSticks.Left.X * speed * Time.deltaTime, state.ThumbSticks.Left.Y * speed * Time.deltaTime, 0.0f);

            transform.localRotation *= Quaternion.Euler(0.0f, 0.0f, state.Triggers.Left * 400.0f * Time.deltaTime);
            transform.localRotation *= Quaternion.Euler(0.0f, 0.0f, state.Triggers.Right * -400.0f * Time.deltaTime);
        }

        if (this.gameObject.transform.localScale == new Vector3(0, 0, 0) && isDead == false)
        {
            gm.deathCount++;
            Debug.Log(this.gameObject.name + "is dead!");
            isDead = true;
        }

        if (isDead)
        {
            this.gameObject.SetActive(false);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Point"))
        {
            transform.localScale += new Vector3(0.5f, 0.5f, 0);
            Destroy(other.gameObject);

        }
    }
}