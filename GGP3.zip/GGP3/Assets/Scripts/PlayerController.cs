﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float rotSpeed = 10;
    public float speed = 10;

    public Rigidbody2D rgb2D;
    public Transform bulletPoint;
    public GameObject bullet;
    public GameMaster gm;

    public string whatever;             //helps associate bulletPoints with correct playersprite

    public bool isDead = false;


    private void Start()
    {
        gm = GameObject.Find("GameMaster").GetComponent<GameMaster>();
        rgb2D = GetComponent<Rigidbody2D>();
        Debug.Log("Start");
        bullet = GameObject.Find("Bullet");
        bulletPoint = GameObject.Find(whatever).GetComponentInChildren<Transform>();

        gameObject.transform.localScale = new Vector3(gm.startingSize, gm.startingSize, 0);
    
    }

    // Update is called once per frame
    void Update()
    {
        //controls
        float hoz = Input.GetAxis("Horizontal");
        float vert = Input.GetAxis("Vertical");
        
        transform.Rotate(Vector3.forward * rotSpeed * -hoz);

        if (hoz == 0)
        {
            transform.Rotate(Vector3.forward * 0);
        }

        transform.Translate(Vector2.up * speed * vert);

        //shooting mechanic
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(bullet, bulletPoint.position, bulletPoint.rotation);
        }

        if (this.gameObject.transform.localScale == new Vector3(0, 0, 0)&& isDead == false)
        {
            gm.deathCount++;
            Debug.Log(this.gameObject.name + "is dead!");
            isDead = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Point"))
        {
            transform.localScale += new Vector3(0.5f, 0.5f, 0);
            Destroy(other.gameObject);

        }
    }
}
