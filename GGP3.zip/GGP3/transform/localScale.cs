﻿namespace transform
{
    internal class localScale
    {
    }
}